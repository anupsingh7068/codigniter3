

<?php

  
if (!function_exists('generate_session_key')) {
    function generate_session_key() {
        $session = rand();
        $encryp = md5($session);
        return $encryp;
    }
}
function password_genret(){
    $otp_password = rand(0000,99999);
    return $otp_password;
}

function checkRequired($array)
{
    $requried = "";
    foreach ($array as $key => $value) {
        if ($value == '') {
            $requried .= $key . ',';
        }
    }
    if ($requried != "") {
        return rtrim($requried, ',') . ' field is required';
    } else {
        return false;
    }

    
}
?>