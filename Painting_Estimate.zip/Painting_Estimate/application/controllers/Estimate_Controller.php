<?php
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';



class Estimate_Controller extends REST_Controller {

    private $param = array();
    private $nonAuthentication_arr = array('Signup','Login','social_login','forget_password');
    private $data = array();
    public $id;
    public $session_key;
    public $method;

    function __construct()
    {
        parent::__construct();
        
       
        $this->load->model('Authentication_Model');
        $this->load->library('form_validation');
        $this->load->model('AuthModel');
        $this->load->helper('custom_helper');
        $this->method = $this->uri->segment(1);
        if (!empty($this->method) && $this->method !== NULL) {
            if (in_array($this->method, $this->nonAuthentication_arr) == false) {
                $data = $this->AuthModel->checkAuth();
                if ($data['status'] != 200) {
                    $this->response($data, $data['status']);
                } else {
                    $this->id = $data['data']['id'];
                    $this->session_key = $data['data']['session_key'];
                }
            }
        } else {
            $data = array('status' => 404, 'message' => 'Not Found');
            $this->response($data, $data['status']);
        }
    }

    #___________________________________________Painting_Estimate___________________________________#

    public function upload_photo_post() {
        $user_id = $this->id;
        $session_key = $this->session_key;
        
        $authentication_check_id_and_session_key = $this->Authentication_Model->get_id_by_session_key($session_key);
           
        if($authentication_check_id_and_session_key && $authentication_check_id_and_session_key->id == $user_id){
           
            $key_field = array(
                 'type' => $this->input->post('type'),
                'Room_Name' => $this->input->post('Room_Name'),
                'Dimensions'=>$this->input->post('Dimensions'),
                'height'=>$this->input->post('height'),
                'width'=>$this->input->post('width'),
                'length'=>$this->input->post('length')
        
        );
            
            if (checkRequired($key_field)) {
                $result = array('status' => 400, 'message' => checkRequired($key_field));
                $this->response($result, $result['status']);
            }
    
            $request =  $this->post();
    
            if (checkRequired($request)) {
                $result = array('status' => 400, 'message' => checkRequired($request));
                $this->response($result, $result['status']);
            }
            if($request['type']==1){
               // Assuming $this->id contains the user_id
$data = array(
    'user_id' => $this->id,
    'Room_Name' => $request['Room_Name'],
    'Dimensions' => $request['Dimensions'],
    'height' => $request['height'],
    'width' => $request['width'],
    'length' => $request['length']
);

$exist_room_name = $this->Authentication_Model->exist_data('room_estimate', $data);

if (!empty($_FILES['image_path']['name'])) {
    
    $config['upload_path'] = './image/';
    $config['allowed_types'] = 'jpg|jpeg|png|gif';
    $config['max_size'] = 2048;
    $config['file_name'] = time();
    $this->load->library('upload', $config);

    if ($this->upload->do_upload('image_path')) {
        $upload_data = $this->upload->data();
        $data['image_path'] = $config['upload_path'] . $upload_data['file_name'];
    } else {
        $this->response([
            'status' => '400',
            'message' => 'Failed to upload image',
            'data' => strip_tags($this->upload->display_errors())
        ], REST_Controller::HTTP_BAD_REQUEST);
        return;
    }
}

if (!$exist_room_name > 0) {
    $data['Room_Name'] = $request['Room_Name'];
}

$upload_image = $this->Authentication_Model->insert('room_estimate', $data);

if ($upload_image) {
    $this->response(['status' => '200', 'message' => 'Successfully uploaded image ', 'data' => $data], REST_Controller::HTTP_OK);
} else {
    $this->response(['status' => '400', 'message' => 'Upload failed'], REST_Controller::HTTP_BAD_REQUEST);
}
}elseif($request['type']==2){
               
              $view_room=  $this->Authentication_Model->view();
            if($view_room){
                $this->response(['status'=>'200','message'=>'All room show','$data'=>$view_room],REST_Controller::HTTP_OK);
            }else{
                $this->response(['status'=>'400','message'=>'Room not found'],REST_Controller::HTTP_BAD_REQUEST);

            }
            }elseif($request['type']==3){

                 $key_field = array('Room_Name'=>$this->input->post('Room_Name')); 
            
               
               if (checkRequired($key_field)) {
                   $result = array('status' => 400, 'message' => checkRequired($key_field));
                   $this->response($result, $result['status']);
               }
       
               $request =  $this->post();
       
               if (checkRequired($request)) {
                   $result = array('status' => 400, 'message' => checkRequired($request));
                   $this->response($result, $result['status']);
               }
              $where = ['Room_Name'=>$request['Room_Name']];
               $select= ['id','user_id','Room_Name','image_path'];
               $user_id = ['user_id'=>$this->id];
               $show_all_color = $this->Authentication_Model->select('room_estimate',$select,$where);
               if($show_all_color){
                $this->response(['status'=>'200','message'=>'Show all color this room','$data'=>$show_all_color],REST_Controller::HTTP_OK);

               }else{
                $this->response(['status'=>'400','message'=>'room is not found'],REST_Controller::HTTP_BAD_REQUEST);

               }
            }else{
                $this->response(['status'=>'400','message'=>'invalid request type'],REST_Controller::HTTP_BAD_REQUEST);

            }

            }
         else {
            $this->response(['status' => '400', 'message' => 'Unauthorized'], REST_Controller::HTTP_UNAUTHORIZED);
        }
    }

    #__________________________________cost_estimate_______________________________________________________________#
/* 
    public function ceiling_cost_estimate_post(){
        $user_id = $this->id;
        $session_key = $this->session_key;
        
        $authentication_check_id_and_session_key = $this->Authentication_Model->get_id_by_session_key($session_key);
           
        if($authentication_check_id_and_session_key && $authentication_check_id_and_session_key->id == $user_id){
        $key_field = array(
            'type'=>$this->input->post('type')
        );
        if (checkRequired($key_field)) {
            $result = array('status' => 400, 'message' => checkRequired($key_field));
            $this->response($result, $result['status']);
        }

        $request =  $this->post();

        if (checkRequired($request)) {
            $result = array('status' => 400, 'message' => checkRequired($request));
            $this->response($result, $result['status']);
        }
        if($request['type']==1){
            if (!empty($_FILES['image_path']['name'])) {
    
                $config['upload_path'] = './image/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['max_size'] = 2048;
                $config['file_name'] = time();
                $this->load->library('upload', $config);
            
                if ($this->upload->do_upload('color_ceiling')) {
                    $upload_data = $this->upload->data();
                    $data['color_ceiling'] = $config['upload_path'] . $upload_data['file_name'];
                } else {
                    $this->response([
                        'status' => '400',
                        'message' => 'Failed to upload image',
                        'data' => strip_tags($this->upload->display_errors())
                    ], REST_Controller::HTTP_BAD_REQUEST);
                    return;
                }
            }
        //    if(isset($request[]))

          }elseif($request['type']==2){

          }
     }
  }
    
}
*/}