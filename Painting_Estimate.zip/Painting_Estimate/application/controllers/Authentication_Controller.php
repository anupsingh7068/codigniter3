<?php
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';



class Authentication_Controller extends REST_Controller {

    private $param = array();
    private $nonAuthentication_arr = array('Signup','Login','social_login','forget_password');
    private $data = array();
    public $id;
    public $session_key;
    public $method;

    function __construct()
    {
        parent::__construct();
        
       
        $this->load->model('Authentication_Model');
        $this->load->library('form_validation');
        $this->load->model('AuthModel');
        $this->load->helper('custom_helper');
        $this->method = $this->uri->segment(1);
        if (!empty($this->method) && $this->method !== NULL) {
            if (in_array($this->method, $this->nonAuthentication_arr) == false) {
                $data = $this->AuthModel->checkAuth();
                if ($data['status'] != 200) {
                    $this->response($data, $data['status']);
                } else {
                    $this->id = $data['data']['id'];
                    $this->session_key = $data['data']['session_key'];
                }
            }
        } else {
            $data = array('status' => 404, 'message' => 'Not Found');
            $this->response($data, $data['status']);
        }
    }
#_____________________________________________signup__________________________________________________________________#
public function Signup_post(){

    $key_filled = array(
        'Name' => $this->input->post('Name'),
        'Email' => $this->input->post('Email'),
        'Password' => $this->input->post('Password'),
        'Confirm_Password' => $this->input->post('Confirm_Password'),
        'Device_Type' => $this->input->post('Device_Type'),
        'Device_Token' => $this->input->post('Device_Token')
    );

    if(checkRequired($key_filled)) {
        $result = array('status' => 400, 'message' => checkRequired($key_filled));
        $this->response($result, $result['status']);
    }
    $request =  $this->post();

    if (checkRequired($request)) {
        $result = array('status' => 400, 'message' => checkRequired($request));
        $this->response($result, $result['status']);
    }
    $data = ['Email' => $request['Email']];
    $check_Mail_Phone = $this->Authentication_Model->exist_data('users', $data);
    if(!$check_Mail_Phone <= 0){
     
        $this->response(['status' => '400', 'message' => 'Email is already in use.'], REST_Controller::HTTP_BAD_REQUEST);
    }
    else{
         $Password = $request['Password'];
         $Confirm_Password = $request['Confirm_Password'];
        if($Password != $Confirm_Password){
            $this->response(['status' => '400', 'message' => 'Passwords do not match'], REST_Controller::HTTP_BAD_REQUEST);

        } else {
            $data = array(
                'Name' => $request['Name'],
                'Email' => $request['Email'],
                'Password' => md5($request['Password']),
                'Device_Type' => $request['Device_Type'],
                'Device_Token' => $request['Device_Token'],
                'created_at' => date('Y-m-d H:i:s '),
                'session_key' => generate_session_key()
                
            );
            $register_data = $this->Authentication_Model->insert('users', $data);
            if($register_data){
                $this->response(['status' => '200', 'message' => 'Successfully Registered', 'data' => $data], REST_Controller::HTTP_OK);

            } else {
                $this->response(['status' => '400', 'message' => 'Registration Failed'], REST_Controller::HTTP_BAD_REQUEST);

            }
                
        }
        
    }

}


#____________________________________________________login_____________________________________________________________
public function Login_post(){

    $key_filled = array(
        'Email' => $this->input->post('Email'),
        'Password' => $this->input->post('Password'),
        'Device_Type' => $this->input->post('Device_Type'),
        'Device_Token' => $this->input->post('Device_Token'),
        // 'is_active' => $this->input->post('is_active')
    );
    if(checkRequired($key_filled)) {
        $result = array('status' => 400, 'message' => checkRequired($key_filled));
        $this->response($result, $result['status']);
    }
    $request =  $this->post();

    if (checkRequired($request)) {
        $result = array('status' => 400, 'message' => checkRequired($request));
        $this->response($result, $result['status']);
    }
    $data = array(
        'Email' => $request['Email'],
        'Password' => md5($request['Password']),
        'Device_Type' => $request['Device_Type'],
        'Device_Token' => $request['Device_Token'],
        // 'is_active' => $request['is_active'],
        'Updated_At' => date('Y-m-d H:i:s '),
        'session_key' => generate_session_key()
    );
    $check_mail_Pass = ['Email' => $request['Email'], 'Password' => md5($request['Password'])];
    $check_login = $this->Authentication_Model->exist_data('users', $check_mail_Pass);
  
    $Email = ['Email' => $request['Email']];

    if($check_login){

      $update_login = $this->Authentication_Model->update('users', $data, $Email);
      $get_details = $this->Authentication_Model->get_data('users', $Email);
        $this->response(['status' => '200', 'message' => 'Successfully logged in', 'data' => $get_details], REST_Controller::HTTP_OK);

    } else {
        $this->response(['status' => '400', 'message' => 'Invalid Email & Password. Please try again.'], REST_Controller::HTTP_BAD_REQUEST);

    }

}

#______________________________________________social_login_____________________________________________________________#
public function social_login_post(){
    $key_filled = array(
        'Social_ID' => $this->input->post('Social_ID'),
        'Login_Type' => $this->input->post('Login_Type'),
        'Device_Type' => $this->input->post('Device_Type'),
        'Device_Token' => $this->input->post('Device_Token')
      
    );

    if(checkRequired($key_filled)) {
        $result = array('status' => 400, 'message' => checkRequired($key_filled));
        $this->response($result, $result['status']);
    }
    $request = $this->post();

    if (checkRequired($request)) {
        $result = array('status' => 400, 'message' => checkRequired($request));
        $this->response($result, $result['status']);
    }

    $data =  array(
        'Social_ID' => $request['Social_ID'],
        'Login_Type' => $request['Login_Type'],
        'Device_Type' => $request['Device_Type'],
        'Device_Token' => $request['Device_Token'],
        'Updated_At' => date('Y-m-d H:i:s ')
    );

    if (isset($request['Email'])) {
        $data['Email'] = $request['Email'];
    }
    $select = ['id', 'Social_ID', 'Login_Type', 'Device_Type', 'Device_Token', 'Updated_At'];
  
   
    $social_id = ['Social_ID' => $request['Social_ID']];
   
    $check_social_id = $this->Authentication_Model->exist_data('users', $social_id);
    if(isset($request['Email'])){
        $mail = ['Email' => $request['Email']];
        $check_mail = $this->Authentication_Model->exist_data('users', $mail);
       if( $check_mail){
        $update = $this->Authentication_Model->update('users', $data, $mail);
        $get_data = $this->Authentication_Model->select('users', $select, $mail);
        $this->response(['status' => '200', 'message' => 'Successfully logged in', 'data' => $get_data], REST_Controller::HTTP_OK);
       }else{
        $insert_social_id = $this->Authentication_Model->insert('users', $data);
        $get_data = $this->Authentication_Model->select('users', $select, $social_id);
        $this->response(['status' => '200', 'message' => 'Successfully logged in', 'data' => $get_data], REST_Controller::HTTP_OK);

       }
        
    } elseif($check_social_id){
        $update = $this->Authentication_Model->update('users', $data, $social_id);
        $get_data = $this->Authentication_Model->select('users', $select, $social_id);
        $this->response(['status' => '200', 'message' => 'Successfully logged in', 'data' => $get_data], REST_Controller::HTTP_OK);

    }
    else {
        $insert_social_id = $this->Authentication_Model->insert('users', $data);
        $get_data = $this->Authentication_Model->select('users', $select, $social_id);
        $this->response(['status' => '200', 'message' => 'Successfully logged in', 'data' => $get_data], REST_Controller::HTTP_OK);

    }
 
}

#___________________________________________Forget_password______________________________________________________________#
public function forget_password_post(){
    $data = array(
        'Email' => $this->input->post('Email'),
        'type' => $this->input->post('type')
    );

    if (checkRequired($data)) {
        $result = array('status' => 400, 'message' => checkRequired($data));
        $this->response($result, $result['status']);
    }

    $request = $this->post();

    if ($request['type'] == 1) {
        $email = ['Email' => $request['Email']];
    
        $mail_check = $this->Authentication_Model->exist_data('users', $email);

        if (!$mail_check) {
            $this->response(['status' => '400', 'message' => 'Email is not correct, please provide the correct email'], REST_Controller::HTTP_BAD_REQUEST);
        } else {
            $this->load->library('phpmailer_lib');
            $mail = $this->phpmailer_lib->load();
            $otp = password_genret();
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'zargam.techwinlabs@gmail.com';
            $mail->Password = 'gkfckkdkawethkmm';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;

            $mail->setFrom('zargam.techwinlabs@gmail.com', 'Reset Password');
            $email = $this->post('Email');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Reset Password';
            $mail->Body = 'Your OTP is: ' . $otp;
            $data = array('otp' => $otp);
            $email = ['Email' => $request['Email']];
            $result = $this->Authentication_Model->update('users', $data, $email);

            if (!$mail->send() && $result) {
                $this->response(['status' => 400, 'message' => 'OTP is not sent'], REST_Controller::HTTP_BAD_REQUEST);
            } else {
                $this->response(['status' => 200, 'message' => 'Successfully sent OTP to your email', 'data' => $data], REST_Controller::HTTP_OK);
            }
        }
    } elseif($request['type'] == 2) {
        $data = array('otp' => $this->input->post('otp'));

        if (checkRequired($data)) {
            $result = array('status' => 400, 'message' => checkRequired($data));
            $this->response($result, $result['status']);
        }
        
        $otp_check = ['otp' => $request['otp'], 'Email' => $request['Email']];
        $verify_otp = $this->Authentication_Model->exist_data('users', $otp_check);
        if($verify_otp){
            $otp = array(
                'otp' => "",
                'verify_otp' => 1
            );
            $email = ['Email' => $request['Email']];
            $update_otp = $this->Authentication_Model->update('users', $otp, $email);
            $this->response(['status' => 200, 'message' => 'OTP is verified. Please set your new password'], REST_Controller::HTTP_OK);

        } else {
            $this->response(['status' => 400, 'message' => 'OTP is not verified'], REST_Controller::HTTP_BAD_REQUEST);

        }

    } elseif($request['type'] == 3) {
        $required_filled  = array(
            'Password' => $this->input->post('Password'),
            'confirm_password' => $this->input->post('confirm_password')
        );
        if (checkRequired($required_filled)) {
            $result = array('status' => 400, 'message' => checkRequired($required_filled));
            $this->response($result, $result['status']);
        }

        $password = $request['Password'];
        $confirm_password = $request['confirm_password'];
        $email = ['Email' => $request['Email']];
        $data = ['verify_otp'];
    
        $select_verifi_otp = $this->Authentication_Model->select('users', $data, $email);
        $verify_otp_status = $select_verifi_otp['verify_otp'];
        if($verify_otp_status == 0){
            $this->response(['status' => '400', 'message' => 'Password was not updated'], REST_Controller::HTTP_BAD_REQUEST);

        } else {
            if($password == $confirm_password){
                $data = ['Password' => md5($request['Password']), 'otp' => "", 'verify_otp' => ""];
                $update_data =  $this->Authentication_Model->update('users', $data, $email);
                $mail_check = $this->Authentication_Model->exist_data('users', $email);

                if($update_data && $mail_check){
                    $this->response(['status' => '200', 'message' => 'Password has been updated'], REST_Controller::HTTP_OK);

                } else {
                    $this->response(['status' => '400', 'message' => 'Password was not updated'], REST_Controller::HTTP_BAD_REQUEST);

                }
            } else {
                $this->response(['status' => '400', 'message' => 'Password and confirm password do not match'], REST_Controller::HTTP_BAD_REQUEST);

            }
        }
       
    }
}


    #_____________________________________________________change_password________________________________________________#
    public function change_password_post(){
        $user_id = $this->id;
        $session_key = $this->session_key;
    
        $authentication_check_id_and_session_key = $this->Authentication_Model->get_id_by_session_key($session_key);
       
        if($authentication_check_id_and_session_key && $authentication_check_id_and_session_key->id == $user_id){
         
            $key_field = array(
                'Email'=>$this->input->post('Email'),
                'Old_Password'=>$this->input->post('Old_Password'),
                'New_Password'=>$this->input->post('New_Password'),
                'Confirm_Password'=>$this->input->post('Confirm_Password')
            );
    
            if (checkRequired($key_field)) {
                $result = array('status' => 400, 'message' => checkRequired($key_field));
                $this->response($result, $result['status']);
            }
    
            $request =  $this->post();
    
            if (checkRequired($request)) {
                $result = array('status' => 400, 'message' => checkRequired($request));
                $this->response($result, $result['status']);
            }
    
            $data = array(
                'Password'=>md5($request['New_Password']),
                'Updated_At'=>date('Y-m-d H:i:s ')
            );
            $select = ['Password'];
            $email = ['Email'=>$request['Email']];
            $get_password = $this->Authentication_Model->select('users',$select,$email);
            $old_pass = $get_password['Password'];
    
            $check_email = $this->Authentication_Model->exist_data('users',$email);
    
            if(!$check_email){
                $this->response(['status'=>'400','message'=>'Invalid Email'],REST_Controller::HTTP_BAD_REQUEST);
            }else{
                if($old_pass != md5($request['Old_Password'])){
                    $this->response(['status'=>'400','message'=>'Incorrect Old Password. Please enter the correct old password.'],REST_Controller::HTTP_BAD_REQUEST);
                }else{
                    if($old_pass == md5($request['New_Password'])){
                        $this->response(['status' => '400', 'message' => 'New Password should be different from the Old Password.'], REST_Controller::HTTP_BAD_REQUEST);
                    }else{
                        if($request['New_Password'] != $request['Confirm_Password']){
                            $this->response(['status' => '400', 'message' => 'New Password and Confirm Password do not match.'], REST_Controller::HTTP_BAD_REQUEST);
                        }else{
                            $update_password = $this->Authentication_Model->update('users',$data,$email);
                            $this->response(['status' => '200', 'message' => 'Password has been successfully updated.'], REST_Controller::HTTP_OK);
                        }
                    }
                }
            }
        }else{
            $this->response([
                'status' => '400',
                'message' => 'Unauthorized: '
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
    #_________________________________________logout_password_________________________________________________________#publ
        public function logout_post(){
            $user_id = $this->id;
            $session_key = $this->session_key;
        
            $authentication_check_id_and_session_key = $this->Authentication_Model->get_id_by_session_key($session_key);
           
            if($authentication_check_id_and_session_key && $authentication_check_id_and_session_key->id == $user_id){
                $request = $this->post();
                $data = array(   
                    'session_key' => "",
                    'is_active' => ""
                );
        
                if($session_key != null){
                    $where = ['id' => $user_id];
                    $logout = $this->Authentication_Model->update('users', $data, $where);
        
                    if($logout){
                        $this->response(['status' => '200', 'message' => 'You have successfully logged out from the device'], REST_Controller::HTTP_OK);
                    } else {
                        $this->response(['status' => '400', 'message' => 'Failed to log out from the device'], REST_Controller::HTTP_BAD_REQUEST);
                    }
                } else {
                    $this->response(['status' => '400', 'message' => 'You are already logged out from the device'], REST_Controller::HTTP_BAD_REQUEST);
                }
            } else {
                $this->response([
                    'status' => '400',
                    'message' => 'Unauthorized: Invalid session key or user ID'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
        
 #________________________________________delete__account_______________________________________________________________#
 public function delete_account_post(){
    $user_id = $this->id;
    $session_key = $this->session_key;

    $authentication_check_id_and_session_key = $this->Authentication_Model->get_id_by_session_key($session_key);
   
    if($authentication_check_id_and_session_key && $authentication_check_id_and_session_key->id == $user_id){
        $where = ['id' => $user_id ];
        $delete_account = $this->Authentication_Model->delete('users', $where);
        if($delete_account){
            $this->response(['status'=>'200','message'=>'Account has been successfully deleted'], REST_Controller::HTTP_OK);
        }
    } else {
        $this->response([
            'status' => '400',
            'message' => 'Unauthorized: Invalid session key or user ID'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}


   #_________________________________profile_update___________________________________________________________________#
   public function update_profile_post(){
    $user_id = $this->id;
    $session_key = $this->session_key;

    $authentication_check_id_and_session_key = $this->Authentication_Model->get_id_by_session_key($session_key);
   
    if($authentication_check_id_and_session_key && $authentication_check_id_and_session_key->id == $user_id){

        if (!empty($_FILES['image_path']['name'])) {
            $config['upload_path'] = './image/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = 2048;
            $config['file_name'] = time();
            $this->load->library('upload', $config);

            if ($this->upload->do_upload('image_path')) {
                $upload_data = $this->upload->data();
                $image_path = $config['upload_path'] . $upload_data['file_name'];
            } else {
                $this->response([
                    'status' => '400',
                    'message' => 'Failed to upload image',
                    'data' => strip_tags($this->upload->display_errors())
                ], REST_Controller::HTTP_BAD_REQUEST);
                return;
            }
        } else {
            $image_path= ''; 
        }

        $request = $this->post();
        $user_data= ['name' => $request['Name'], 'image' => $image_path];

        $data = array_filter($user_data);

        $user_id_array = ['id' => $this->id];
        $result = $this->Authentication_Model->update('users', $data, $user_id_array);
        $update_result = $this->Authentication_Model->get_data('users', $user_id_array);

        if ($result && $update_result) {
            $this->response([
                'status' => '200',
                'message' => 'Profile successfully updated',
                'data' => $update_result
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => '400',
                'message' => 'Failed to update profile',
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    } else {
        $this->response([
            'status' => '400',
            'message' => 'Unauthorized: Invalid session key or user ID'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}
#_____________________________________________client_details____________________________________________________________#
public function client_details_post(){
    $user_id = $this->id;
    $session_key = $this->session_key;

    $authentication_check_id_and_session_key = $this->Authentication_Model->get_id_by_session_key($session_key);
   
    if($authentication_check_id_and_session_key && $authentication_check_id_and_session_key->id == $user_id){
    $key_field = array(

        'phone'=>$this->input->post('phone'),
        'address'=>$this->input->post('address'),
        'city'=>$this->input->post('city'),
        'estimate_date'=>$this->input->post('estimate_date'),
        'job_type'=>$this->input->post('job_type'),
     
    );
    if (checkRequired($key_field)) {
        $result = array('status' => 400, 'message' => checkRequired($key_field));
        $this->response($result, $result['status']);
    }
 
    $request =  $this->post();

    if (checkRequired($request)) {
        $result = array('status' => 400, 'message' => checkRequired($request));
        $this->response($result, $result['status']);
    }
    $email = ['email'=>$authentication_check_id_and_session_key->Email];
    /* print_r($email);
    die; */
    $user_id = ['client_id'=>$this->id];
   $allready_details_exist = $this->Authentication_Model->exist_data('client_details',$user_id);
   if($allready_details_exist){
   // $this->response(['status' => '400', 'message' => 'allredy submit details'], REST_Controller::HTTP_BAD_REQUEST);
     if(isset($request['phone'])){
        $data['phone'] = $request['phone'];
     }
     if(isset($request['address'])){
        $data['address'] = $request['address'];
     }
     if(isset($request['phone'])){
        $data['city'] = $request['city'];
     }
     if(isset($request['phone'])){
        $data['estimate_date'] = $request['estimate_date'];
     }
     if(isset($request['job_type'])){
        $data['job_type'] = $request['job_type'];
     }
      $update_details= $this->Authentication_Model->update('client_details',$data,$user_id);
      $show_client_details = $this->Authentication_Model->show_details('client_details',$user_id);
      if( $show_client_details){
          $this->response(['status'=>'200','message'=>'show_client details','data'=>$show_client_details],REST_Controller::HTTP_OK);
      }else{
          $this->response(['status'=>'400','message'=>'No found client details',],REST_Controller::HTTP_BAD_REQUEST);
  
      }
    }
    
    else{
   $data = array(
    'client_id'=>$this->id,
    'name'=>$authentication_check_id_and_session_key->Name,
    'email'=>$authentication_check_id_and_session_key->Email,
    'phone'=>$request['phone'],
    'address'=>$request['address'],
    'city'=>$request['city'],
    'estimate_date'=>$request['estimate_date'],
    'job_type'=>$request['job_type'],

  );
  $user_id = ['client_id'=>$this->id];
   $client_details_insert = $this->Authentication_Model->insert('client_details',$data);
   $show_client_details = $this->Authentication_Model->show_details('client_details',$user_id);
    if( $show_client_details){
        $this->response(['status'=>'200','message'=>'show_client details','data'=>$show_client_details],REST_Controller::HTTP_OK);
    }else{
        $this->response(['status'=>'400','message'=>'No found client details',],REST_Controller::HTTP_BAD_REQUEST);

    }
    }
    }
}

}