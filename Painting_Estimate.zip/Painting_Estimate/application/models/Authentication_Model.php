<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication_Model extends CI_Model {

    public function insert($table,$data){
      return  $this->db->insert($table,$data);
    }

    public function exist_data($table,$data){
        return  $this->db->get_where($table,$data)->num_rows();
    }

    public function update($table, $data,$where){
        $this->db->where($where);
      return  $this->db->update($table,$data);
       
    }
    public function get_data($table, $where){
        $this->db->select('*')->select('Password');
        $this->db->where($where);
        $this->db->from($table);
         $result = $this->db->get()->result();
         foreach ($result as $row) {
            unset($row->Password);
        }
    
        return $result;
    }
    public function select($table,$select,$where){
        $this->db->select($select);
      return  $this->db->get_where($table,$where)->result_array();
    }
    public function get_id_by_session_key($id){
        $this->db->where('session_key',$id);
       return $this->db->get('users')->row();
    }
    public function delete($table, $where){
        $this->db->where($where);
        return $this->db->delete($table);
    }
 /* public function view(){
  return $this->db->select('Room_Name')->from('room_estimate') ->group_by('Room_Name')
  ->get()->result_array();
  
 

 } */
 public function show_details($table,$where){
  $this->db->select('*');
  $this->db->where($where);
 return $this->db->get($table)->result_array();
 }
}
?>