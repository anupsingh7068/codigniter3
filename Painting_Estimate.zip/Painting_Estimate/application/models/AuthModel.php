<?php

class AuthModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Authentication_Model');
    }


    public function checkAuth()
    {
        $check = array('id' => $this->input->get_request_header('id', TRUE), 'session_key' => $this->input->get_request_header('session_key', TRUE));

        if (checkRequired($check)) {
            return array('status' => 400, 'message' => "Header Request : " .checkRequired($check));
        } else {
            $id = $this->input->get_request_header('id', TRUE);
            $session_key = $this->input->get_request_header('session_key', TRUE);
            if ($this->AuthModel->checkSession(array('id' => $id, 'session_key' => $session_key)) != 200) {
                return array('status' => 401, 'message' =>  'Unauthorized');
            } else {
                return array('status' => 200, 'data' => array('id' => $id, 'session_key' => $session_key));
            }
        }
    }

    public function checkSession($data)
    {
        // $check = $this->Authentication_Model->get_data('user', array('id' => $data['id'], 'session_key' => $data['session_key']));

        $check = $this->db->query(" SELECT * FROM `users` WHERE `id` = '". $data['id']."' AND `session_key` = '". $data['session_key']."'")->num_rows();
        
        if ($check > 0) {
            return 200;
        } else {
            return 401;
        }
    }
    
}